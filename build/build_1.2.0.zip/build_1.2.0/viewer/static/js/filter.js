$("body").on("click", ".filter.button", function(){
    $(".filter.form").transition('slide down');
});