toastr.options.escapeHtml = true;
toastr.options.closeButton = true;
toastr.options.progressBar = true;
toastr.options.extendedTimeOut = 60;
toastr.options.timeOut = 800;

toastr.options.showMethod = 'slideDown';
toastr.options.hideMethod = 'slideUp';
