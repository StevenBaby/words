# encoding=utf-8
from __future__ import print_function, unicode_literals, division

EXIT = 0
SKIP = 1
PLAY = 2
PARA = 3

ERROR = 4
RIGHT = 5
EQUAL = 6
